PB数据交换模型
====
### 生成C++文件命令:
#### protoc -I=./ --cpp_out=./ *.proto
### 生成Python文件命令：
#### protoc -I=. --python_out=./ *.proto